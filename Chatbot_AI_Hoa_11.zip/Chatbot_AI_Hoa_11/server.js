import "dotenv/config";
import express from "express";
import { GoogleGenAI } from "@google/genai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const dir = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(dir,"public")));

const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY}) : null;
const systemInstruction = `
Bạn là HóaBạn 11, trợ lý AI dạy và học Hóa học lớp 11 bằng tiếng Việt.
Hỗ trợ học sinh giải thích lý thuyết, bài tập, phương trình phản ứng, hiện tượng hóa học và ôn tập.
Các chủ đề có thể gồm: cân bằng hóa học; cân bằng trong dung dịch nước; nitrogen và sulfur; đại cương hóa học hữu cơ; hydrocarbon; dẫn xuất halogen; alcohol, phenol; hợp chất carbonyl và carboxylic acid. Nội dung có thể khác theo bộ sách, hãy hỏi tên bài/bộ sách nếu cần.
Với bài tính toán: ghi dữ kiện, yêu cầu, công thức/phương trình, thay số có đơn vị, giải từng bước, kết luận.
Với phản ứng: viết phương trình cân bằng, điều kiện và hiện tượng quan trọng.
Với lý thuyết: nêu khái niệm, bản chất, ví dụ và ý cần nhớ.
Không tự bịa dữ kiện, nội dung sách, số liệu hoặc trích dẫn. Nếu đề thiếu hoặc ảnh không rõ, hãy nói rõ và yêu cầu bổ sung.
Trình bày đúng trình độ lớp 11, thân thiện, dễ hiểu. Nếu không chắc, hãy thừa nhận giới hạn.
`;

app.post("/api/chat", async (req,res)=>{
  try {
    if(!ai) return res.status(500).json({error:"Chưa cấu hình GEMINI_API_KEY trên máy chủ."});
    const messages=req.body?.messages;
    if(!Array.isArray(messages)||!messages.length) return res.status(400).json({error:"Bạn hãy nhập câu hỏi."});
    const history=messages.slice(-12,-1).map(m=>({
      role:m.role==="assistant"?"model":"user",
      parts:[{text:String(m.content||"").slice(0,6000)}]
    }));
    const latest=messages[messages.length-1];
    if(latest.role!=="user") return res.status(400).json({error:"Tin nhắn cuối phải là câu hỏi."});
    const chat=ai.chats.create({model:"gemini-2.5-flash",config:{systemInstruction},history});
    const result=await chat.sendMessage({message:String(latest.content||"").slice(0,6000)});
    res.json({reply:result.text||"Mình chưa tạo được câu trả lời, bạn thử lại nhé."});
  } catch(e) {
    console.error(e);
    res.status(500).json({error:"Lỗi kết nối AI. Hãy kiểm tra API key, hạn mức và cấu hình máy chủ."});
  }
});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log("Chatbot Hóa 11 chạy ở cổng "+port));
