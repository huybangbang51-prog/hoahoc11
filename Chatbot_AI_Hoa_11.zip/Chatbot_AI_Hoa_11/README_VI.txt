CHATBOT AI HÓA HỌC 11 – HƯỚNG DẪN CÀI ĐẶT

1. Tạo Gemini API key
Mở https://aistudio.google.com/app/apikey, đăng nhập Google và tạo API key.
Không gửi API key cho người khác và không đưa key vào public/index.html.

2. Chạy thử trên máy tính
- Cài Node.js 20 trở lên.
- Giải nén ZIP, mở Terminal/CMD tại thư mục dự án.
- Chạy: npm install
- Sao chép .env.example thành .env.
- Điền API key vào biến GEMINI_API_KEY trong file .env.
- Chạy: npm start
- Mở http://localhost:3000

3. Đưa chatbot lên Render
- Đẩy thư mục dự án lên repository GitHub.
- Vào https://render.com, tạo Web Service từ repository.
- Build Command: npm install
- Start Command: npm start
- Trong Environment, thêm GEMINI_API_KEY và dán API key.
- Deploy; mở URL Render được cấp để kiểm tra.

4. Nhúng vào Google Sites
- Mở Google Sites ở chế độ chỉnh sửa.
- Chọn Chèn (Insert) → Nhúng (Embed) → Theo URL (By URL).
- Dán URL Render → Chèn, điều chỉnh kích thước khung.
- Xuất bản website.

Chatbot dùng Gemini qua máy chủ Node.js. API key chỉ được lưu ở biến môi trường máy chủ.
Nội dung được định hướng theo Hóa học 11; các chủ đề có thể khác giữa các bộ sách.
Nếu lỗi API, kiểm tra API key, hạn mức và model Gemini được hỗ trợ trong tài khoản.
